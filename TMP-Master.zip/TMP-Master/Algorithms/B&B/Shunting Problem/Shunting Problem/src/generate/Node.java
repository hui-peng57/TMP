package generate;

import java.util.ArrayList;

public final class Node {
	public String type;
	public String fatherType;
	public int locoPushMove;
	public int locoPullMove;
	public int wagonPushMove;
	public int wagonPullMove;
	public ArrayList<ArrayList<Integer>> trackStatus;
	public ArrayList<Integer> locoStatus;
	public ArrayList<Integer> trackSet;
	public ArrayList<Integer> track;
	public StringBuffer operationPlan;
	public int disorder;
	
	public Node() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Node(String type, String fatherType, int locoPushMove,
			int locoPullMove, int wagonPushMove, int wagonPullMove,
			ArrayList<ArrayList<Integer>> trackStatus,
			ArrayList<Integer> locoStatus, ArrayList<Integer> trackSet,
			ArrayList<Integer> track, StringBuffer operationPlan, int disorder) {
		super();
		this.type = type;
		this.fatherType = fatherType;
		this.locoPushMove = locoPushMove;
		this.locoPullMove = locoPullMove;
		this.wagonPushMove = wagonPushMove;
		this.wagonPullMove = wagonPullMove;
		this.trackStatus = trackStatus;
		this.locoStatus = locoStatus;
		this.trackSet = trackSet;
		this.track = track;
		this.operationPlan = operationPlan;
		this.disorder = disorder;
	}

}
