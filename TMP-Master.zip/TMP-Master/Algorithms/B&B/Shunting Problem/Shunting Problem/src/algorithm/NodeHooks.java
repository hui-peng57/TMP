package algorithm;

import generate.Node;

import java.util.ArrayList;

public final class NodeHooks {
	//�÷�������ڵ�����ÿһ���ҹ�����Ź�
	public final static void shuntingTrip(ArrayList<Integer> trackNum,ArrayList<Integer> num,Node node,ArrayList<Integer> dis,int number,int start,int end){
		if(end == dis.size()){
			trackNum.add(dis.get(start));
			num.add(number);
			return;
		}
		if(dis.get(start) != dis.get(end)){
			trackNum.add(dis.get(start));
			num.add(number);
			number=1;
			shuntingTrip(trackNum,num,node,dis,number,end,end+1);
		}else{
			number++;
			shuntingTrip(trackNum,num,node,dis,number,start,end+1);
		}
	}
}
