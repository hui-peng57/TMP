package algorithm;

import generate.Node;

import java.util.ArrayList;

public final class A1 {
	public static int weight_lPull = 20;
	public static int weight_lPush = 5;
	public static int weight_wPull = 1;
	public static int weight_wPush = 1;
	//�÷�������assignment node���ӽڵ�
	public final static void track_c(Node node,Node boundNode,ArrayList<Node> arrayNode){
		ArrayList<ArrayList<Integer>> allSubset = new ArrayList<ArrayList<Integer>>();
		int notEmpty = -1;
		if(node.disorder != 0){ 
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					notEmpty++;
					if(node.trackStatus.get(i).get(0) != boundNode.locoStatus.get(0)){
						ArrayList<Integer> trackSet = new ArrayList<Integer>();
						trackSet.add(i); //ÿ���������Ϊһ������
						allSubset.add(trackSet);
					}
				}
			}
		}else{
			ArrayList<Integer> trackSet = new ArrayList<Integer>();
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					notEmpty++;
					boolean flag = true;
					boolean sign = true;
					if(node.trackStatus.get(i).get(0) == boundNode.locoStatus.get(0)){
						flag = false;
						for(int j=0;j<node.trackStatus.get(i).size();j++){
							if(node.trackStatus.get(i).get(j) != boundNode.locoStatus.get(j)){
								sign = false;
								break;
							}
						}
					}
					if(flag == true){
						trackSet.add(i);
					}else if(sign == false){
						trackSet.add(i);
					}
				}
			}
			allSubset.add(trackSet);
		}
		for(ArrayList<Integer> subset: allSubset){
			int movement1 = weight_lPull*(node.locoPullMove+notEmpty)+weight_lPush*(node.locoPushMove)+weight_wPull*node.wagonPullMove+weight_wPush*node.wagonPushMove;
			int movement2 = weight_lPull*boundNode.locoPullMove+weight_lPush*boundNode.locoPushMove+weight_wPull*boundNode.wagonPullMove+weight_wPush*boundNode.wagonPushMove;
			if(movement1 <= movement2){
				createNode(node,arrayNode,subset);
			}
		}
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	
	//�÷�������collecting node���ӽڵ�
	public final static void track_a(Node node,Node boundNode,ArrayList<Node> arrayNode){
		ArrayList<Integer> availableTrack = new ArrayList<Integer>();
		if(node.disorder == 0){
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					availableTrack.add(i);
				}
			}
		}else{
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				availableTrack.add(i);
			}
		}
		ArrayList<ArrayList<Integer>> allSubset = new ArrayList<ArrayList<Integer>>(); //����ͬtrack_c��ĸñ���
		generateSub(allSubset,availableTrack); //����generateSub���������ɿ��ù������ȫ���Ӽ�
		screenOut(allSubset,node); //����screenOut��������allSubset����ظ��Ӽ�ɸ��
		for(ArrayList<Integer> subset: allSubset){
			int empty = 0;
			for(Integer i: subset){
				if(node.trackStatus.get(i).isEmpty()){
					empty++;
				}
			}
			int pulls = -1;
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					pulls++;
				}
			}
			int movement1 = weight_lPull*(node.locoPullMove+empty+pulls)+weight_lPush*(node.locoPushMove)+weight_wPull*node.wagonPullMove+weight_wPush*node.wagonPushMove;
			int movement2 = weight_lPull*boundNode.locoPullMove+weight_lPush*boundNode.locoPushMove+weight_wPull*boundNode.wagonPullMove+weight_wPush*boundNode.wagonPushMove;
			if(movement1 <= movement2){
				createNode(node,arrayNode,subset);
			}
		}
		//end
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	
	//���ɿ��ù�������зǿ��Ӽ��������������λ���㣩
	public final static void generateSub(ArrayList<ArrayList<Integer>> allSubset,ArrayList<Integer> availableTrack){
		int num = availableTrack.size()==0?0:1<<availableTrack.size();
		for(int i=0;i<num;i++){
			ArrayList<Integer> subset = new ArrayList<Integer>();
			int index = i;
			for(int j=0;j<availableTrack.size();j++){
				if((index&1)==1){
					subset.add(availableTrack.get(j));
				}
				index>>=1;
			}
			if(subset.size()!=0){
				allSubset.add(subset); //�ѷǿյ��Ӽ�����allSubset
			}
		}
	}
	
	//ɸ���ظ������
	public final static void screenOut(ArrayList<ArrayList<Integer>> allSubset,Node node){
		for(int i=0;i<allSubset.size()-1;i++){
			//���м��������Ƚϣ����չ��������ͬ�ҷǿչ����ͬ������Ϊ�ظ���ȡһ�����У�ʣ�µ��Ƴ�
			ArrayList<Integer> subset1 = allSubset.get(i);
			ArrayList<Integer> notEmpty1 = new ArrayList<Integer>();
			int numEmpty1 = 0;
			for(int j=0,len=subset1.size();j<len;j++){
				if(!node.trackStatus.get(subset1.get(j)).isEmpty()){
					notEmpty1.add(subset1.get(j));
				}else{
					numEmpty1++;
				}
			}
			for(int k=i+1;k<allSubset.size();k++){
				ArrayList<Integer> subset2 = allSubset.get(k);
				ArrayList<Integer> notEmpty2 = new ArrayList<Integer>();
				int numEmpty2 = 0;
				for(int m=0,len=subset2.size();m<len;m++){
					if(!node.trackStatus.get(subset2.get(m)).isEmpty()){
						notEmpty2.add(subset2.get(m));
					}else{
						numEmpty2++;
					}
				}
				if(numEmpty1 == numEmpty2 && notEmpty1.containsAll(notEmpty2) && notEmpty2.containsAll(notEmpty1)){
					allSubset.remove(k);
					k--;  //����ɾ��Ԫ�غ�©�Ƚ�
				}
			}
		}
	}
	
	//����track set node
	public final static void createNode(Node node,ArrayList<Node> arrayNode,ArrayList<Integer> subset){
		//�Ѹ��ڵ��type��trackStatus��locoStatus��trackSet��operationPlanȫ���������������ﲻ���á�=��ֱ�Ӹ�������Ϊ���������á�=���Ǹ���ֵַ������������
		String fatherType = "";
		for(int i=0;i<node.type.length();i++){
			fatherType+=node.type.charAt(i);
		} 
		int locoPushMove = node.locoPushMove;
		int locoPullMove = node.locoPullMove;
		int wagonPushMove = node.wagonPushMove;
		int wagonPullMove = node.wagonPullMove;
		ArrayList<ArrayList<Integer>> trackStatus = new ArrayList<ArrayList<Integer>>();
		for(int j=0,len=node.trackStatus.size();j<len;j++){  
			ArrayList<Integer> array = new ArrayList<Integer>();
			array.addAll(node.trackStatus.get(j));
			trackStatus.add(array);
		}
		ArrayList<Integer> locoStatus = new ArrayList<Integer>();
		locoStatus.addAll(node.locoStatus);
		ArrayList<Integer> trackSet = new ArrayList<Integer>();
		trackSet.addAll(subset);
		ArrayList<Integer> track= new ArrayList<Integer>();
		track.addAll(node.track);
		StringBuffer operationPlan = new StringBuffer();
		for(int j=0,len=node.operationPlan.length();j<len;j++){
			operationPlan.append(node.operationPlan.charAt(j));
		}
		int disorder = node.disorder;
		arrayNode.add(new Node("t",fatherType,locoPushMove,locoPullMove,wagonPushMove,wagonPullMove,trackStatus,locoStatus,trackSet,track,operationPlan,disorder));
	}
}
