package algorithm;

import generate.Node;

import java.util.ArrayList;

public final class InitialUB {
	public static boolean flag = false;
	//�÷��������ʼ�Ͻ�
	public final static void upperBound(Node boundNode,ArrayList<Node> arrayNode){
		//begin ����δ��֧�ڵ㼯
		while(flag == false){ //���ҵ�һ�����н�ʱ��flag��Ϊtrue��ѭ������������ļ��㷽��������A1��A2��A3��ͬ��ֻ��ÿ�η�֧ʱ��������С�Ľڵ������֧
			Node node = bestNode(arrayNode);
			if(node.type.equals("a")){
				track_c(node,boundNode,arrayNode);
			}else if(node.type.equals("c")){
				track_a(node,arrayNode);
			}else if(node.type.equals("t")){
				if(node.fatherType.equals("c")){
					assigning(node,boundNode,arrayNode);
				}else{
					collecting(node,arrayNode);
				}
			}
		}
		//end
	}
	
	//�÷�������assignment node���ӽڵ�
	public final static void track_c(Node node,Node boundNode,ArrayList<Node> arrayNode){
		ArrayList<ArrayList<Integer>> allSubset = new ArrayList<ArrayList<Integer>>();
		if(node.disorder != 0){
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					ArrayList<Integer> trackSet = new ArrayList<Integer>();
					trackSet.add(i); 
					allSubset.add(trackSet);	
				}
			}
		}else{
			ArrayList<Integer> trackSet = new ArrayList<Integer>();
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					boolean flag = true;
					boolean sign = true;
					if(node.trackStatus.get(i).get(0) == boundNode.locoStatus.get(0)){
						flag = false;
						for(int j=0;j<node.trackStatus.get(i).size();j++){
							if(node.trackStatus.get(i).get(j) != boundNode.locoStatus.get(j)){
								sign = false;
								break;
							}
						}
					}
					if(flag == true){
						trackSet.add(i);
					}else if(sign == false){
						trackSet.add(i);
					}
				}
			}
			allSubset.add(trackSet);
		}
		for(ArrayList<Integer> subset: allSubset){
			A1.createNode(node,arrayNode,subset);
		}
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	
	//�÷�������collecting node���ӽڵ�
	public final static void track_a(Node node,ArrayList<Node> arrayNode){
		ArrayList<Integer> availableTrack = new ArrayList<Integer>();
		if(node.disorder == 0){
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				if(!node.trackStatus.get(i).isEmpty()){
					availableTrack.add(i);
				}
			}
		}else{
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				availableTrack.add(i);
			}
		}
		ArrayList<ArrayList<Integer>> allSubset = new ArrayList<ArrayList<Integer>>();
		A1.generateSub(allSubset,availableTrack);
		A1.screenOut(allSubset,node);
		for(ArrayList<Integer> subset: allSubset){
			A1.createNode(node,arrayNode,subset);
		}
		//end
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	
	//�÷�������assignment node
	public final static void assigning(Node node,Node boundNode,ArrayList<Node> arrayNode){
		ArrayList<ArrayList<Integer>> allDis = new ArrayList<ArrayList<Integer>>(); 
		ArrayList<Integer> distribution = new ArrayList<Integer>(); 
		if(node.disorder == 0){
			A2.distribute(node,allDis,distribution,node.trackSet,node.locoStatus.size(),0);
		}else{
			for(int num = node.trackSet.size();num<=node.locoStatus.size();num++){ 
				A2.distribute(node,allDis,distribution,node.trackSet,num,0);
			}
		}
		for(ArrayList<Integer> dis: allDis){
			ArrayList<Integer> trackNum = new ArrayList<Integer>(); 
			ArrayList<Integer> num = new ArrayList<Integer>();  
			int number = 1;
			NodeHooks.shuntingTrip(trackNum,num,node,dis,number,0,1);
			if(node.track.isEmpty()){
				createANode(node,boundNode,arrayNode,trackNum,num);
			}else if(trackNum.get(0) != node.track.get(node.track.size()-1)){
				createANode(node,boundNode,arrayNode,trackNum,num);
			}
			if(flag == true){
				break;
			}
		}
		arrayNode.remove(node);
	}
	public final static void createANode(Node node,Node boundNode,ArrayList<Node> arrayNode,ArrayList<Integer> trackNum,ArrayList<Integer> num){
		int locoPushMove = node.locoPushMove;
		int locoPullMove = node.locoPullMove;
		int wagonPushMove = node.wagonPushMove;
		int wagonPullMove = node.wagonPullMove;
		ArrayList<ArrayList<Integer>> trackStatus = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<node.trackStatus.size();i++){
			ArrayList<Integer> array = new ArrayList<Integer>();
			array.addAll(node.trackStatus.get(i));
			trackStatus.add(array);
		}
		ArrayList<Integer> locoStatus = new ArrayList<Integer>();
		locoStatus.addAll(node.locoStatus);
		ArrayList<Integer> trackSet = new ArrayList<Integer>();
		trackSet.addAll(node.trackSet);
		ArrayList<Integer> track = new ArrayList<Integer>();
		track.addAll(trackNum);
		StringBuffer operationPlan = new StringBuffer();
		for(int i=0;i<node.operationPlan.length();i++){
			operationPlan.append(node.operationPlan.charAt(i));
		}
		for(int i=0;i<trackNum.size();i++){ //������¼�������ļ���
			locoPushMove+=1; //��Ź�+1
			wagonPushMove+=(2*locoStatus.size()-num.get(i)); //������ŵ��Ƴ�����
			for(int j=0;j<num.get(i);j++){ //���µ����߼�����״̬
				trackStatus.get(trackNum.get(i)).add(locoStatus.get(0));
				locoStatus.remove(0);
			}
			String s1 = trackNum.get(i).toString();
			operationPlan.append(s1);
			operationPlan.append("-");
			String s2 = num.get(i).toString();
			operationPlan.append(s2);
			operationPlan.append(" ");
			int disorder = Disorder.calDis(trackStatus, locoStatus);
			operationPlan.append(disorder);
			operationPlan.append(" ");
		}
		int disorder = Disorder.calDis(trackStatus, locoStatus);
		Node newNode = new Node("a","t",locoPushMove,locoPullMove,wagonPushMove,wagonPullMove,trackStatus,locoStatus,trackSet,track,operationPlan,disorder);
		for(int i=0;i<trackStatus.size();i++){
			if(trackStatus.get(i).size() == boundNode.locoStatus.size()){
				boolean sign = true;
				for(int j=0;j<trackStatus.get(i).size();j++){
					if(trackStatus.get(i).get(j)!=boundNode.locoStatus.get(j)){
						sign = false;
						break;
					}
				}
				if(sign == true){
					flag = true;
					boundNode.locoPullMove = locoPullMove;
					boundNode.locoPushMove = locoPushMove;
					boundNode.wagonPullMove = wagonPullMove;
					boundNode.wagonPushMove = wagonPushMove;
					boundNode.operationPlan.delete(0,boundNode.operationPlan.length()-1);
					boundNode.operationPlan.append(operationPlan.toString());
				}
			}
		}
		if(flag == false && disorder <= node.disorder){
			arrayNode.add(newNode);
		}
	}
	
	//�÷�������collecting node
	public final static void collecting(Node node,ArrayList<Node> arrayNode){
		int numWagons = 0;
		for(int i=0;i<node.trackSet.size();i++){
			numWagons += node.trackStatus.get(node.trackSet.get(i)).size();
		}
		ArrayList<ArrayList<Integer>> allChoice = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> choice = new ArrayList<Integer>();
		if(node.disorder == 0){
			A3.choose(node,allChoice,choice,node.trackSet,numWagons,0);
		}else{
			for(int num=node.trackSet.size();num<=numWagons;num++){
				A3.choose(node,allChoice,choice,node.trackSet,num,0);
			}
		}
		for(ArrayList<Integer> array: allChoice){
			ArrayList<Integer> trackNum = new ArrayList<Integer>();
			ArrayList<Integer> num = new ArrayList<Integer>();  
			int number = 1;
			NodeHooks.shuntingTrip(trackNum,num,node,array,number,0,1);
			if(node.track.isEmpty()){
				createCNode(node,arrayNode,trackNum,num);
			}else if(trackNum.get(0) != node.track.get(node.track.size()-1)){
				createCNode(node,arrayNode,trackNum,num);
			}
		}
		arrayNode.remove(node);
	}
	public final static void createCNode(Node node,ArrayList<Node> arrayNode,ArrayList<Integer> trackNum,ArrayList<Integer> num){
		int locoPushMove = node.locoPushMove;
		int locoPullMove = node.locoPullMove;
		int wagonPushMove = node.wagonPushMove;
		int wagonPullMove = node.wagonPullMove;
		ArrayList<ArrayList<Integer>> trackStatus = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<node.trackStatus.size();i++){
			ArrayList<Integer> arr1 = new ArrayList<Integer>();
			arr1.addAll(node.trackStatus.get(i));
			trackStatus.add(arr1);
		}
		ArrayList<Integer> locoStatus = new ArrayList<Integer>();
		locoStatus.addAll(node.locoStatus);
		ArrayList<Integer> trackSet = new ArrayList<Integer>();
		trackSet.addAll(node.trackSet);
		ArrayList<Integer> track = new ArrayList<Integer>();
		track.addAll(trackNum);
		StringBuffer operationPlan = new StringBuffer();
		for(int i=0;i<node.operationPlan.length();i++){
			operationPlan.append(node.operationPlan.charAt(i));
		}
		for(int i=0;i<trackNum.size();i++){
			locoPullMove+=1;
			wagonPullMove+=(2*locoStatus.size()+num.get(i));
			for(int j=0;j<num.get(i);j++){
				locoStatus.add(0,trackStatus.get(trackNum.get(i)).get(trackStatus.get(trackNum.get(i)).size()-1));
				trackStatus.get(trackNum.get(i)).remove(trackStatus.get(trackNum.get(i)).size()-1);
			}
			String s1 = trackNum.get(i).toString();
			String s2 = num.get(i).toString();
			operationPlan.append(s1);
			operationPlan.append("+");
			operationPlan.append(s2);
			operationPlan.append(" ");
			int disorder = Disorder.calDis(trackStatus, locoStatus);
			operationPlan.append(disorder);
			operationPlan.append(" ");
		}
		int disorder = Disorder.calDis(trackStatus, locoStatus);
		if(disorder <= node.disorder){
			Node newNode = new Node("c","t",locoPushMove,locoPullMove,wagonPushMove,wagonPullMove,trackStatus,locoStatus,trackSet,track,operationPlan,disorder);
			arrayNode.add(newNode);
		}
	}
	//�÷���Ѱ��������С�Ľڵ�
	public static Node bestNode(ArrayList<Node> arrayNode){
		int minDisorder = 9999;
		Node node = new Node();
		for(Node n: arrayNode){
			if(n.disorder < minDisorder){
				node = n;
				minDisorder = n.disorder;
			}
		}
		return node;
	}
}
