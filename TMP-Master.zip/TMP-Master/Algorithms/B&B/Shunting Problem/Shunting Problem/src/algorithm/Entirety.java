package algorithm;

import java.util.ArrayList;

public class Entirety {
	//�÷��������Ҫ��Ϊ���崦���ĳ�
	public final static ArrayList<ArrayList<Integer>> checkWhole(ArrayList<Integer> locoStatus,ArrayList<Integer> targetBlock){
		ArrayList<ArrayList<Integer>> wholeArray = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> flag = new ArrayList<Integer>();
		for(int i=0;i<targetBlock.size();i++){
			flag.add(0);
		}
		for(int i=0,len1=locoStatus.size();i<len1;i++){
			for(int j=0,len2=targetBlock.size();j<len2;j++){
				if(locoStatus.get(i) == targetBlock.get(j) && flag.get(j) == 0){
					int n = j;
					int number = 0;
					for(int m=i;m<len1;m++){
						if(n<len2){
							if(locoStatus.get(m) == targetBlock.get(n) && flag.get(n) == 0){
								number++;
								n++;
							}else{
								break;
							}
						}
					}
					if(number >= 2){
						boolean sign = true;
						for(int x=i;x<number+i-1;x++){
							if(locoStatus.lastIndexOf(locoStatus.get(x)) >= number+i){
								sign = false;
								break;
							}
						}
						if(sign == true){
							ArrayList<Integer> array = new ArrayList<Integer>();
							ArrayList<Integer> car = new ArrayList<Integer>();
							for(int k=i;k<number+i;k++){
								array.add(k);
								car.add(locoStatus.get(k));
							}
							int data = 0;
							for(int k = 0;k<locoStatus.size();k++){
								if(locoStatus.get(k) == car.get(0) && locoStatus.size()-k >= car.size()){
									boolean mark = true;
									for(int x=0;x<car.size();x++){
										if(locoStatus.get(k+x) != car.get(x)){
											mark = false;
											break;
										}
									}
									if(mark == true){
										data++;
										k += car.size()-1;
									}
								}
							}
							if(data == 1){
								wholeArray.add(array);
								for(int k=j;k<number+j;k++){
									flag.set(k, 1);
								}
							}
						}
						i += number-1;
						break;
					}
				}
			}
		}
		return wholeArray;
	}
}
