package algorithm;

import generate.Node;

import java.util.ArrayList;
import java.util.HashMap;

public final class A3 {
	public static int weight_lPull = 20;
	public static int weight_lPush = 5;
	public static int weight_wPull = 1;
	public static int weight_wPush = 1;
	//�÷�������collecting node
	public final static void collecting(Node node,Node boundNode,ArrayList<Node> arrayNode){
		int numWagons = 0;
		for(int i=0;i<node.trackSet.size();i++){
			numWagons += node.trackStatus.get(node.trackSet.get(i)).size();
		} 
		ArrayList<ArrayList<Integer>> allChoice = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> choice = new ArrayList<Integer>();
		if(node.disorder == 0){
			choose(node,allChoice,choice,node.trackSet,numWagons,0);
		}else{
			for(int num=node.trackSet.size();num<=numWagons;num++){
				choose(node,allChoice,choice,node.trackSet,num,0);
			}
		}
		for(ArrayList<Integer> choi: allChoice){
			HashMap<Integer,ArrayList<Integer>> track_num = new HashMap<Integer,ArrayList<Integer>>();
			for(int i=0,len=node.trackStatus.size();i<len;i++){
				ArrayList<Integer> array = new ArrayList<Integer>();
				for(int j=0;j<choi.size();j++){
					if(i == choi.get(j)){
						array.add(j);
					}
				}
				if(!array.isEmpty()){
					track_num.put(i, array);
				}
			}
			ArrayList<Integer> key = new ArrayList<Integer>();
			key.addAll(track_num.keySet());
			boolean sign = true;
			for(int i=0;i<key.size();i++){
				ArrayList<ArrayList<Integer>> wholeArray = Entirety.checkWhole(node.trackStatus.get(key.get(i)), boundNode.locoStatus);
				if(wholeArray.size() != 0){
					ArrayList<Integer> array = track_num.get(key.get(i));
					for(ArrayList<Integer> whole: wholeArray){
						if(array.size() >= node.trackStatus.get(key.get(i)).size()-whole.get(whole.size()-1) && array.size() < node.trackStatus.get(key.get(i)).size()-whole.get(0)){
							sign = false;
							break;
						}else if(array.size() >= node.trackStatus.get(key.get(i)).size()-whole.get(0)){
							for(int j=node.trackStatus.get(key.get(i)).size()-1-whole.get(whole.size()-1);j<whole.size()-1;j++){
								if(array.get(j)+1 != array.get(j+1)){
									sign = false;
									break;
								}
							}
						}
					}
				}
			}
			if(sign == true){
				//begin 
				ArrayList<Integer> trackNum = new ArrayList<Integer>();  //��¼ÿ���Ĺ��
				ArrayList<Integer> num = new ArrayList<Integer>();  //��¼ÿ���ĳ���
				int number = 1;
				NodeHooks.shuntingTrip(trackNum,num,node,choi,number,0,1);
				//end
				if(trackNum.get(0) != node.track.get(node.track.size()-1)){
					createCNode(node,boundNode,arrayNode,trackNum,num);
				}
			}
		}
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	//�������п��еĳ������ҷ���
	public final static void choose(Node node,ArrayList<ArrayList<Integer>> allChoice,ArrayList<Integer> choice,ArrayList<Integer> trackSet,int num,int start){
		if(start == num){ //�ﵽ��Ҫ������ҳ�������
			boolean flag = true;
			for(int i=0;i<trackSet.size();i++){
				if(!choice.contains(trackSet.get(i))){ //�жϸ����ҷ����Ƿ������track set node��ȫ�������ȫ�������Ĳ��ǿ��еķ���
					flag = false;
					break;
				}
				int total = 0;
				for(int j=0;j<choice.size();j++){
					if(choice.get(j) == trackSet.get(i)){
						total++;
					}
				}
				if(total > node.trackStatus.get(trackSet.get(i)).size()){
					flag = false;
				}
			}
			if(flag == true){
				ArrayList<Integer> array = new ArrayList<Integer>();
				array.addAll(choice);
				allChoice.add(array);
			}
			return;
		}
		for(int i=0;i<trackSet.size();i++){ 
			choice.add(trackSet.get(i));
			choose(node,allChoice,choice,trackSet,num,start+1);
			choice.remove(choice.size()-1);
		}
	}
	public final static void createCNode(Node node,Node boundNode,ArrayList<Node> arrayNode,ArrayList<Integer> trackNum,ArrayList<Integer> num){
		//begin �Ӹ��ڵ�̳������Ϣ
		int locoPushMove = node.locoPushMove;
		int locoPullMove = node.locoPullMove;
		int wagonPushMove = node.wagonPushMove;
		int wagonPullMove = node.wagonPullMove;
		ArrayList<ArrayList<Integer>> trackStatus = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<node.trackStatus.size();i++){
			ArrayList<Integer> array = new ArrayList<Integer>();
			array.addAll(node.trackStatus.get(i));
			trackStatus.add(array);
		}
		ArrayList<Integer> locoStatus = new ArrayList<Integer>();
		locoStatus.addAll(node.locoStatus);
		ArrayList<Integer> trackSet = new ArrayList<Integer>();
		trackSet.addAll(node.trackSet);
		ArrayList<Integer> track = new ArrayList<Integer>();
		track.addAll(trackNum);
		StringBuffer operationPlan = new StringBuffer();
		for(int i=0;i<node.operationPlan.length();i++){
			operationPlan.append(node.operationPlan.charAt(i));
		}
		//end
		//begin ���µ����߼�����״̬����¼ÿ�����ж�
		for(int i=0;i<trackNum.size();i++){
			locoPullMove+=1;
			wagonPullMove+=(2*locoStatus.size()+num.get(i));
			for(int j=0;j<num.get(i);j++){
				locoStatus.add(0,trackStatus.get(trackNum.get(i)).get(trackStatus.get(trackNum.get(i)).size()-1));
				trackStatus.get(trackNum.get(i)).remove(trackStatus.get(trackNum.get(i)).size()-1);
			}
			String s1 = trackNum.get(i).toString();
			String s2 = num.get(i).toString();
			operationPlan.append(s1);
			operationPlan.append("+");
			operationPlan.append(s2);
			operationPlan.append(" ");
			int disorder = Disorder.calDis(trackStatus, locoStatus);
			operationPlan.append(disorder);
			operationPlan.append(" ");
		}
		int disorder = Disorder.calDis(trackStatus, locoStatus);
		//begin ��֧/�����Ͻ�
		int notEmpty = -1;
		for(int i=0,len=trackStatus.size();i<len;i++){
			if(!trackStatus.get(i).isEmpty()){
				notEmpty ++;
			}
		}
		int movement1 = 0;
		if(notEmpty != 0){
			movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*(locoPushMove+2)+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove;
		}else{
			movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*(locoPushMove+1)+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove;
		}
		int movement2 = weight_lPull*boundNode.locoPullMove+weight_lPush*boundNode.locoPushMove+weight_wPull*boundNode.wagonPullMove+weight_wPush*boundNode.wagonPushMove;
		if(movement1 < movement2){
			Node newNode = new Node("c","t",locoPushMove,locoPullMove,wagonPushMove,wagonPullMove,trackStatus,locoStatus,trackSet,track,operationPlan,disorder);
			arrayNode.add(newNode);
		}
		//end
	}
}
