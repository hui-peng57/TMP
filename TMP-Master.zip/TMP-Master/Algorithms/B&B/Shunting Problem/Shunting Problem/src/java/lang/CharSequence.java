package java.lang;

public class CharSequence {

}
