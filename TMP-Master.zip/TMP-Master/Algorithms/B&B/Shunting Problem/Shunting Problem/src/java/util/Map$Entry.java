package java.util;

public class Map$Entry {

}
