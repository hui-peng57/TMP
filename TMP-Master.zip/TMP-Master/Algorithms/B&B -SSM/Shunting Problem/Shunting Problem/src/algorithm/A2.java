package algorithm;

import generate.Node;

import java.util.ArrayList;

public final class A2 {
	public static int weight_lPull = 20;
	public static int weight_lPush = 5;
	public static int weight_wPull = 1;
	public static int weight_wPush = 1;
	//�÷�������assignment node
	public final static void assigning(Node node,Node boundNode,ArrayList<Node> arrayNode){
		ArrayList<ArrayList<Integer>> allDis = new ArrayList<ArrayList<Integer>>(); //��¼������ŷ����ļ���
		ArrayList<Integer> distribution = new ArrayList<Integer>(); 
		if(node.disorder == 0){
			distribute(node,allDis,distribution,node.trackSet,node.locoStatus.size(),0);
		}else{
			for(int num = node.trackSet.size();num<=node.locoStatus.size();num++){ //��ÿ�ֿ�����ŵĳ���������distribute��������ȫ����
				distribute(node,allDis,distribution,node.trackSet,num,0);
			}
		}
		ArrayList<ArrayList<Integer>> wholeArray = Entirety.checkWhole(node.locoStatus,boundNode.locoStatus);
		for(ArrayList<Integer> dis: allDis){
			boolean sign = true;
			if(wholeArray.size() != 0){
				for(ArrayList<Integer> whole: wholeArray){
					if(dis.size() >= whole.get(0)+1 && dis.size() < whole.get(whole.size()-1)+1){
						sign = false;
						break;
					}else if(dis.size() >= whole.get(whole.size()-1)+1){
						int track = dis.get(whole.get(0));
						for(Integer i: whole){
							if(dis.get(i) != track){
								sign = false;
								break;
							}
						}
					}
				}
			}
			if(sign == true){
				//begin ��ÿ�����еķ���������ST���е�shuntingTrip����ȷ�������ÿ���Ĺ��������
				ArrayList<Integer> trackNum = new ArrayList<Integer>();  //��¼ÿ���Ĺ��
				ArrayList<Integer> num = new ArrayList<Integer>();  //��¼ÿ���ĳ���
				int number = 1;
				NodeHooks.shuntingTrip(trackNum,num,node,dis,number,0,1);
				//end
				if(node.track.isEmpty()){
					createANode(node,boundNode,arrayNode,trackNum,num);
				}else if(trackNum.get(0) != node.track.get(node.track.size()-1)){
					createANode(node,boundNode,arrayNode,trackNum,num);
				}
			}
		}
		arrayNode.remove(node);  //�Ƴ����ڵ�
	}
	
	//�������п��е���ŷ������ݹ飩
	public final static void distribute(Node node,ArrayList<ArrayList<Integer>> allDis,ArrayList<Integer> distribution,ArrayList<Integer> trackSet,int num,int start){
		if(start == num){ //�ﵽ��Ҫ����ų�������
			boolean flag = true;
			for(int i=0;i<trackSet.size();i++){
				if(!distribution.contains(trackSet.get(i))){ //�жϸ���ŷ����Ƿ������track set node��ȫ�������ȫ�������Ĳ��ǿ��еķ���
					flag = false;
					break;
				}
			}
			if(flag == true){
				ArrayList<Integer> array = new ArrayList<Integer>();
				array.addAll(distribution);
				allDis.add(array);
			}
			return;
		}
		for(int i=0;i<trackSet.size();i++){
			distribution.add(trackSet.get(i));
			distribute(node,allDis,distribution,trackSet,num,start+1);
			distribution.remove(distribution.size()-1);
		}
	}
	
	public final static void createANode(Node node,Node boundNode,ArrayList<Node> arrayNode,ArrayList<Integer> trackNum,ArrayList<Integer> num){
		//begin �Ӹ��ڵ�̳������Ϣ
		int locoPushMove = node.locoPushMove;
		int locoPullMove = node.locoPullMove;
		int wagonPushMove = node.wagonPushMove;
		int wagonPullMove = node.wagonPullMove;
		ArrayList<ArrayList<Integer>> trackStatus = new ArrayList<ArrayList<Integer>>();
		for(int i=0;i<node.trackStatus.size();i++){
			ArrayList<Integer> array = new ArrayList<Integer>();
			array.addAll(node.trackStatus.get(i));
			trackStatus.add(array);
		}
		ArrayList<Integer> locoStatus = new ArrayList<Integer>();
		locoStatus.addAll(node.locoStatus);
		ArrayList<Integer> trackSet = new ArrayList<Integer>();
		trackSet.addAll(node.trackSet);
		ArrayList<Integer> track = new ArrayList<Integer>();
		track.addAll(trackNum);
		StringBuffer operationPlan = new StringBuffer();
		for(int i=0;i<node.operationPlan.length();i++){
			operationPlan.append(node.operationPlan.charAt(i));
		}
		//end
		//begin ���µ����߼�����״̬����¼ÿ�����ж�
		for(int i=0;i<trackNum.size();i++){ //������¼�������ļ���
			locoPushMove+=1; //��Ź�+1
			wagonPushMove+=(2*locoStatus.size()-num.get(i)); //������ŵ��Ƴ�����
			for(int j=0;j<num.get(i);j++){ //���µ����߼�����״̬
				trackStatus.get(trackNum.get(i)).add(locoStatus.get(0));
				locoStatus.remove(0);
			}
			String s1 = trackNum.get(i).toString();
			operationPlan.append(s1);
			operationPlan.append("-");
			String s2 = num.get(i).toString();
			operationPlan.append(s2);
			operationPlan.append(" ");
			int disorder = Disorder.calDis(trackStatus, locoStatus);
			operationPlan.append(disorder);
			operationPlan.append(" ");//���µ�����ҵ�ƻ�
		}
		int disorder = Disorder.calDis(trackStatus, locoStatus); //��������
		//begin ��֧
		if(judge(trackStatus,boundNode.locoStatus)){
			int notEmpty = -1;
			for(int i=0,len=trackStatus.size();i<len;i++){
				if(!trackStatus.get(i).isEmpty()){
					notEmpty ++;
				}
			}
			int movement1 = 0;
			if(disorder != 0){
				movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*(locoPushMove+2)+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove;
			}else if(notEmpty != 0){
				movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*(locoPushMove+1)+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove; 
			}else{
				movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*locoPushMove+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove; 
			}
			int movement2 = weight_lPull*boundNode.locoPullMove+weight_lPush*boundNode.locoPushMove+weight_wPull*boundNode.wagonPullMove+weight_wPush*boundNode.wagonPushMove; //�Ͻ��Ŀ�꺯��ֵ
			if(movement1 < movement2 && disorder <= node.disorder){ //����Ŀ�꺯��С���Ͻ�����������������������ӽڵ㣬������arrayNode
				boolean flag = false;
				boolean sign = true;
				for(int i=0;i<trackStatus.size();i++){
					if(trackStatus.get(i).size() == boundNode.locoStatus.size()){
						flag = true;
						for(int j=0;j<trackStatus.get(i).size();j++){
							if(trackStatus.get(i).get(j)!=boundNode.locoStatus.get(j)){
								sign = false;
								break;
							}
						}
					}
				}
				if(flag == true && sign == true){
					boundNode.locoPullMove = locoPullMove;
					boundNode.locoPushMove = locoPushMove;
					boundNode.wagonPullMove = wagonPullMove;
					boundNode.wagonPushMove = wagonPushMove;
					boundNode.operationPlan.delete(0,boundNode.operationPlan.length()-1);
					boundNode.operationPlan.append(operationPlan.toString());
					System.out.println("���ҹ�����"+boundNode.locoPullMove+"   "
							+"��Ź�����"+boundNode.locoPushMove+"   "
							+"���ҵ��Ƴ�������"+boundNode.wagonPullMove+"   "
							+"��ŵ��Ƴ�������"+boundNode.wagonPushMove);
					System.out.println("������ҵ�ƻ���"+boundNode.operationPlan); //�����ʼ�Ͻ���Ϣ
					System.out.println();
				}else{
					movement1 = weight_lPull*(locoPullMove+notEmpty)+weight_lPush*(locoPushMove+1)+weight_wPull*wagonPullMove+weight_wPush*wagonPushMove; 
					if(movement1 < movement2){
						Node newNode = new Node("a","t",locoPushMove,locoPullMove,wagonPushMove,wagonPullMove,trackStatus,locoStatus,trackSet,track,operationPlan,disorder);
						arrayNode.add(newNode);
					}
				}
			}
		}
		//end
	}
	public final static boolean judge(ArrayList<ArrayList<Integer>> trackStatus,ArrayList<Integer> targetBlock){
		boolean flag = true;
		for(ArrayList<Integer> track_i: trackStatus){
			if(!track_i.isEmpty()){
				if(track_i.get(0) == targetBlock.get(0)){
					for(int i=0,len=track_i.size();i<len;i++){
						if(track_i.get(i) != targetBlock.get(i)){
							flag = false;
						}
					}
				}
			}
		}
		return flag;
	}
}
